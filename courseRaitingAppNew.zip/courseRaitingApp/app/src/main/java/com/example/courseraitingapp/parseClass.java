package com.example.courseraitingapp;

import android.os.Parcel;
import android.os.Parcelable;
import android.widget.Spinner;

public class parseClass implements Parcelable {
        private String FirstName;
        private String LastName;
        private String SpinnerTeacher;
        private String SpinnerSemester;

    public parseClass(String firstName, String lastName, String spinnerTeacher, String spinnerSemester) {
        FirstName = firstName;
        LastName = lastName;
        SpinnerTeacher = spinnerTeacher;
        SpinnerSemester = spinnerSemester;
    }

    protected parseClass(Parcel in) {
        FirstName = in.readString();
        LastName = in.readString();
        SpinnerTeacher = in.readString();
        SpinnerSemester = in.readString();
    }

    public static final Creator<parseClass> CREATOR = new Creator<parseClass>() {
        @Override
        public parseClass createFromParcel(Parcel in) {
            return new parseClass(in);
        }

        @Override
        public parseClass[] newArray(int size) {
            return new parseClass[size];
        }
    };

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public String getSpinnerTeacher() {
        return SpinnerTeacher;
    }

    public String getSpinnerSemester() {
        return SpinnerSemester;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(FirstName);
        dest.writeString(LastName);
        dest.writeString(SpinnerTeacher);
        dest.writeString(SpinnerSemester);
    }
}


