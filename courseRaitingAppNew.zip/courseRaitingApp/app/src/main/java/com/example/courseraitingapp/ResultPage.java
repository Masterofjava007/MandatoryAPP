package com.example.courseraitingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ResultPage extends AppCompatActivity {
    public static final String myEmail = "Steffenkea95@gmail.com";
    private EditText email_subject, email_edittext;
    private String email_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_email);


        Intent QuestionIntent = getIntent();
        resultParse questionParse = QuestionIntent.getParcelableExtra("modtag");

        email_message = questionParse.getTeacher() + " - " + questionParse.getSemester() + "\n" + questionParse.getQuestionOne() + ". - " + questionParse.getSpinnerOne() + "\n" +
        questionParse.getQuestionTwo() + ". - " + questionParse.getSpinnerTwo() + "\n" +
        questionParse.getQuestionThree() + ". - " + questionParse.getSpinnerThree()+ "\n" +
        questionParse.getQuestionFour() + ". - " + questionParse.getSpinnerFour() + "\n" +
        questionParse.getQuestionFive() + ". - " + questionParse.getSpinnerFive();

        TextView email_to = findViewById(R.id.email_to);
        email_subject = findViewById(R.id.email_subject);
        email_edittext = findViewById(R.id.edit_text);
        Button mailBut = findViewById(R.id.mailBut);
        email_to.setText(myEmail);
        email_edittext.setText(email_message);

        mailBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                sendMail();
            }
        });

    }
    private void sendMail() {

        String subject = email_subject.getText().toString();
        String text = email_edittext.getText().toString();


        Intent intent =  new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, myEmail);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, text);

        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "Choose an Email clien"));
    }
}
