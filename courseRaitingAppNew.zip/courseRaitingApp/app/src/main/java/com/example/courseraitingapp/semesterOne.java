package com.example.courseraitingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class semesterOne extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private TextView FirstName, LastName;
    private Spinner spinnerTeacher, spinnerSemester;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semester_one);



        FirstName = findViewById(R.id.FirstName);
        LastName = findViewById(R.id.LastName);
        spinnerTeacher = findViewById(R.id.spinnerTeacher);
        spinnerSemester = findViewById(R.id.SpinnerSemester);
        Button NextPage = findViewById(R.id.Next);

        ArrayAdapter<CharSequence> adapterSem = ArrayAdapter.createFromResource(this, R.array.Semester, android.R.layout.simple_spinner_item);
        adapterSem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSemester.setAdapter(adapterSem);

        spinnerSemester.setOnItemSelectedListener(this);
        spinnerTeacher.setOnItemSelectedListener(this);



        NextPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String spinTeacherRs = spinnerTeacher.getSelectedItem().toString();
                String spinSemesterRs = spinnerSemester.getSelectedItem().toString();
                parseClass parse = new parseClass(FirstName.getText().toString(), LastName.getText().toString(), spinTeacherRs, spinSemesterRs);

                Intent intent = new Intent(semesterOne.this, QuestionPage.class);
                intent.putExtra("send", parse);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String toast = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}



