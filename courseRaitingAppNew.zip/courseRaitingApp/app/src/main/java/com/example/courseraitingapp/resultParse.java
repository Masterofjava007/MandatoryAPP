package com.example.courseraitingapp;

import android.os.Parcel;
import android.os.Parcelable;

public class resultParse implements Parcelable {
    private String teacher;
    private String semester;
    private String questionOne;
    private String questionTwo;
    private String questionThree;
    private String questionFour;
    private String questionFive;
    private String spinnerOne;
    private String spinnerTwo;
    private String spinnerThree;
    private String spinnerFour;
    private String spinnerFive;

    public resultParse(String teacher, String semester, String questionOne, String questionTwo, String questionThree, String questionFour, String questionFive, String spinnerOne, String spinnerTwo, String spinnerThree, String spinnerFour, String spinnerFive) {
        this.teacher = teacher;
        this.semester = semester;
        this.questionOne = questionOne;
        this.questionTwo = questionTwo;
        this.questionThree = questionThree;
        this.questionFour = questionFour;
        this.questionFive = questionFive;
        this.spinnerOne = spinnerOne;
        this.spinnerTwo = spinnerTwo;
        this.spinnerThree = spinnerThree;
        this.spinnerFour = spinnerFour;
        this.spinnerFive = spinnerFive;
    }

    protected resultParse(Parcel in) {
        teacher = in.readString();
        semester = in.readString();
        questionOne = in.readString();
        questionTwo = in.readString();
        questionThree = in.readString();
        questionFour = in.readString();
        questionFive = in.readString();
        spinnerOne = in.readString();
        spinnerTwo = in.readString();
        spinnerThree = in.readString();
        spinnerFour = in.readString();
        spinnerFive = in.readString();
    }

    public static final Creator<resultParse> CREATOR = new Creator<resultParse>() {
        @Override
        public resultParse createFromParcel(Parcel in) {
            return new resultParse(in);
        }

        @Override
        public resultParse[] newArray(int size) {
            return new resultParse[size];
        }
    };

    public String getTeacher() {
        return teacher;
    }

    public String getSemester() {
        return semester;
    }

    public String getQuestionOne() {
        return questionOne;
    }

    public String getQuestionTwo() {
        return questionTwo;
    }

    public String getQuestionThree() {
        return questionThree;
    }

    public String getQuestionFour() {
        return questionFour;
    }

    public String getQuestionFive() {
        return questionFive;
    }

    public String getSpinnerOne() {
        return spinnerOne;
    }

    public String getSpinnerTwo() {
        return spinnerTwo;
    }

    public String getSpinnerThree() {
        return spinnerThree;
    }

    public String getSpinnerFour() {
        return spinnerFour;
    }

    public String getSpinnerFive() {
        return spinnerFive;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(teacher);
        dest.writeString(semester);
        dest.writeString(questionOne);
        dest.writeString(questionTwo);
        dest.writeString(questionThree);
        dest.writeString(questionFour);
        dest.writeString(questionFive);
        dest.writeString(spinnerOne);
        dest.writeString(spinnerTwo);
        dest.writeString(spinnerThree);
        dest.writeString(spinnerFour);
        dest.writeString(spinnerFive);
    }
}