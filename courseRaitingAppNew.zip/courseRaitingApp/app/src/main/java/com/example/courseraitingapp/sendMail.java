package com.example.courseraitingapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.se.omapi.Session;
import android.widget.Toast;

import java.util.Properties;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.util.Properties;


public class sendMail extends AsyncTask<Void, Void, Void> {

    private Context context;
    private Session session;

    private String email;
    private String subject;
    private String message;

    private ProgressDialog progressDialog;


    public sendMail(Context context, Session session, String email, String subject, String message) {
        this.context = context;
        this.session = session;
        this.email = email;
        this.subject = subject;
        this.message = message;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        progressDialog = progressDialog.show(context,"Sending message", "please wait....",false,false);
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        progressDialog.dismiss();
        Toast.makeText(context,"message sent", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected Void doInBackground(Void... params)  {
        Properties props  = new Properties();

        //Config Information for Gmail Properties
        props.put("mail.smpt.host", "smtp,gmail.com");
        props.put("mail.smpt.socketFactory.port", "465");
        props.put("mail.smpt.SocketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smpt.auth", "true");
        props.put("mail.smtp.port", "465");

        //Laver en ny Session







        return null;
    }
}
