package com.example.courseraitingapp;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class QuestionPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private ConstraintLayout constraintLayout;
    private TextView questionOne, questionTwo, questionThree, questionFour, questionFive, semester, teacher;
    private Spinner spinnerOne, spinnerTwo, spinnerThree, spinnerFour, spinnerFive;
    private String saveon = "SaveOn";

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(saveon, String.valueOf(spinnerOne));
    }

    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_page);

        constraintLayout = findViewById(R.id.snackbar_action);
        semester = findViewById(R.id.Semester);
        teacher = findViewById(R.id.Teacher);
        TextView firstname = findViewById(R.id.FirstName);
        TextView lastName = findViewById(R.id.LastName);

        TextView disc = findViewById(R.id.discribtion);
        questionOne = findViewById(R.id.questionOne);
        questionTwo = findViewById(R.id.questionTwo);
        questionThree = findViewById(R.id.questionThree);
        questionFour = findViewById(R.id.questionFour);
        questionFive = findViewById(R.id.questionFive);

        spinnerOne = findViewById(R.id.spinnerOne);
        spinnerTwo = findViewById(R.id.spinnerTwo);
        spinnerThree = findViewById(R.id.spinnerThree);
        spinnerFour = findViewById(R.id.spinnerFour);
        spinnerFive = findViewById(R.id.spinnerFive);

        spinnerOne.setOnItemSelectedListener(this);
        spinnerTwo.setOnItemSelectedListener(this);
        spinnerThree.setOnItemSelectedListener(this);
        spinnerFour.setOnItemSelectedListener(this);
        spinnerFive.setOnItemSelectedListener(this);


        Button buttonRes = findViewById(R.id.ButtonRes);


        final Intent intent = getIntent();
        parseClass fromSemOne = intent.getParcelableExtra("send");

        semester.setText(fromSemOne.getSpinnerSemester());
        teacher.setText("Teacher: " + fromSemOne.getSpinnerTeacher());
        firstname.setText("Name: " + fromSemOne.getFirstName());
        lastName.setText("Lastname: " + fromSemOne.getLastName());

        buttonRes.setOnClickListener(new View.OnClickListener() {

            String spinOneRes = spinnerOne.getSelectedItem().toString();
            String spinTwoRes = spinnerTwo.getSelectedItem().toString();
            String spinThreeRes = spinnerThree.getSelectedItem().toString();
            String spinFourRes = spinnerFour.getSelectedItem().toString();
            String spinFiveRes = spinnerFive.getSelectedItem().toString();
            @Override
            public void onClick(View v) {
                resultParse resultParse = new resultParse(teacher.getText().toString(), semester.getText().toString(), questionOne.getText().toString(), questionTwo.getText().toString(),
                        questionThree.getText().toString(), questionFour.getText().toString(), questionFive.getText().toString(),
                        spinOneRes, spinTwoRes, spinThreeRes, spinFourRes, spinFiveRes);
                Intent intent1 = new Intent(QuestionPage.this, ResultPage.class);
                intent1.putExtra("modtag",resultParse);
                startActivity(intent1);
        }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String toast = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void ShowSnachbar() {
        Snackbar snackbar = Snackbar.make(constraintLayout, "Are you Sure?", Snackbar.LENGTH_INDEFINITE)
                .setAction("Forsæt", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent = new Intent(QuestionPage.this, ResultPage.class);

                        startActivity(intent);
                    }
                });
               /* .setAction("Undo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar undoSnack = Snackbar.make(constraintLayout, "Try Again", Snackbar.LENGTH_SHORT);
                undoSnack.show();
            }
        });*/
        snackbar.show();
    }
}
